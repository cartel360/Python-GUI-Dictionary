import json
from difflib import get_close_matches

data = json.load(open("data.json"))
keys = data.keys()


def meaning():
    w = e1_value.get()

    if w in data:
        for i, j in enumerate(data[w]):
            t1.insert(END,str(i)+' '+j+'\n')
    elif w.upper() in data: #in case user enters words like USA or NATO
        for i, j in enumerate(data[w.upper()]):
            t1.insert(END,str(i)+' '+j+'\n')
    elif w.title() in data: #if user entered "texas" this will check for "Texas" as well.
        for i, j in enumerate(data[w.title()]):
            t1.insert(END,str(i)+' '+j+'\n')
    else:
        list=g(w,keys,n=1,cutoff=0.8)
        if len(list) == 0:
            t1.insert(END, "The word doesn't exist. Please double check it.")
        else:
            real=list[0]
            answer=tkinter.messagebox.askquestion("Word Suggestion", "Is Your Word "+real+"?")

            if answer == "yes":
                for i, j in enumerate(data[real]):
                    t1.insert(END,str(i)+' '+j+'\n')
            else:
                t1.insert(END,"Apologies, No Word Found, Please Recheck Your Input Word.")


def meaning2():
    t1.delete(1,0,END)
    e1.delete(0,END)

    meaning
